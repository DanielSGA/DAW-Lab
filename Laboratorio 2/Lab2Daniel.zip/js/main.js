document.addEventListener("DOMContentLoaded", function(event) 
{
    var input = document.getElementById("newitem");

    input.addEventListener("keyup", function(event) 
    {
        event.preventDefault();
        if(event.keyCode == 13) 
        {
            newElement();
        }
    });

    newElement = () => 
    {
        let inputTask = input.value;

        if(inputTask != "")
        {
            let inNode = document.createTextNode(inputTask);
            let id = Date.now();
            let li = document.createElement("li");

            let text = document.createElement("text");
            text.setAttribute("label", id);
            text.appendChild(inNode);

            let checkbox = document.createElement("input");
            checkbox.setAttribute("type", "checkbox");
            checkbox.className = "list_checkbox";
            checkbox.setAttribute("onchange", "check(this)");
            li.appendChild(checkbox);
            li.appendChild(text);

            document.getElementById("myList").appendChild(li);
            document.getElementById("newitem").value = "";
        }
    }
});